<?php
return [
    'adminEmail' => 'andrewpraveen.n@gmail.com',
    'supportEmail' => 'admin@nationsvoice.com.lk',
    'senderEmail' => 'andrewpraveen.n@gmail.com',
    'senderName' => 'Example.com mailer',
    'user.passwordResetTokenExpire' => 3600,
    'user.passwordMinLength' => 8,
    'uploadPathIMG' => dirname(dirname(__DIR__)) . '/backend/web/uploads/',
    'back_host' => 'http://wms/uploads/'
];
